// vue.config.js
module.exports = {
    // 选项...
    publicPath: "./",
};
